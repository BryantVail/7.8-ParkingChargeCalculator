﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BryantVCh7_8
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Charge'em by MacroSoft");
            double hoursParked = 0;
            double parkingCost = 0;
            string strHoursParked;
            DateTime DailyClock = new DateTime();
            DateTime Today = new DateTime();
            Today = DateTime.Today;
            DailyClock = Today;

            //Loop for Parking Tally
            while (hoursParked != -1234)
            {

                Console.WriteLine(" Please Enter the amount of hours parked below:");
                Console.Read();
                ParkingGarage CalculateParkingCost = new ParkingGarage();
                strHoursParked = Console.ReadLine();
                ParkingGarage.InputString2DoubleHoursParked( strHoursParked);
                
                CalculateParkingCost.CalculateCharges(ParkingGarage.HoursParked);

            //parkingCost = CalculateParkingCost.CalculateCharges(hoursParked);

            //ParkingGarage.RunningTotal += parkingCost; 
            //ParkingGarage TotalTally = new ParkingGarage();
                CalculateParkingCost.ParkingCostTally();
            Console.Read(); 
            }
            


        }
    }
}
