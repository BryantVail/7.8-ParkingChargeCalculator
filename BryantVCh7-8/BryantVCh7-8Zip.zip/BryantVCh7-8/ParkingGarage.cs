﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BryantVCh7_8
{
    class ParkingGarage
    {
        //Public counter/accumulators
        public double CarCounter = 0;
        public double RunningTotal = 0;
        public double TotalCost = 0;
        static public double HoursParked = 0;


        //Calculate parking charges, insert the hours parked in the garage
        public double CalculateCharges(double hoursParked)
        {
            TotalCost = 0;
            HoursParked = hoursParked;
            //return value = totalCharge
            double totalCharge = 2.00;
            //amount being added to the total for each additional hour over the base
	        double additionalHour = .5;

            if (HoursParked <= 3)
            {
                return totalCharge;
                TotalCost = totalCharge;
                CarCounter++;
                RunningTotal = (RunningTotal + TotalCost);
            }

            else if (HoursParked > 3)
            {
                totalCharge = ((HoursParked - 3) * (additionalHour)) + totalCharge;
                CarCounter = CarCounter + 1;
                
                if (totalCharge > 10)
                    TotalCost = totalCharge = 10.00;
                else
                    return TotalCost;
                RunningTotal = RunningTotal + TotalCost;
            }
            else
            {
                return 0;
            }
    return TotalCost;
        }

        //Collect data from Console.ReadLine() & Validate to double
        static public void  InputString2DoubleHoursParked(string hoursParked)
        {
            //Converted value holder
            double hoursDouble = 1234567;
            bool validEntry = false;
            ////IF statement to set bool Valid Entry
            //if (hoursDouble == 0)
            //    validEntry = false;

            while(hoursDouble == 1234567)
            {
                 try
                {
                   hoursDouble = Convert.ToDouble(hoursParked);
                   
                   HoursParked = hoursDouble;
                   break;

                }
                    catch
                {
                  Console.WriteLine("Please Enter a Valid Number of hours");
                  break;
                } 
            }
            
            
                   
        }
        
        public void ParkingCostTally()
        { 
            double totalRunning = 0;
            double totalInstance = 0;



            Console.WriteLine("Thank you for calculating parking cost today! \n Cost For Parking Duration:\t " + TotalCost +"\t"+ HoursParked + "\t" +" \nRunning Cost For Parking Duration \nTotal \tCars \tTotal Amount \n\t" + CarCounter + "\t" + RunningTotal);
            
        }

    }
}
